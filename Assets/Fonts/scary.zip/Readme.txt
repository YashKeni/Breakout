  Hello and thanks for the interest. This is made from a scan of my hand-scribbling. The idea was to write out the characters as quick
 as possible. I didn't even bother with all the characters. This little message is the usual crap about the struggling graphic artist. 
If you like this font, go ahead and use it or distribute it freely. (just keep this readme intact) If you REALLY like it, send me something!
like a zine or a jpeg or even a buck or two. Anything would put a smile on my face. Thanks,


Kevin Byrd
box 41302
Tucson, AZ 85717-1302
serious@rtd.com
http://users.lanminds.com/~serious